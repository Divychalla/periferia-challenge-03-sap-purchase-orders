# Periferia challenge 03 — SAP Purchase Orders

A standalone TypeScript agent that reads the supplied request fixtures, validates purchase-order controls, prepares a traceable SAP-shaped payload, generates approval evidence and writes orders to a file-backed SAP simulation.

## Run locally

Requirements: Node.js 20 or newer and pnpm.

```bash
cp .env.example .env
pnpm install
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000). Without `OPENAI_API_KEY`, the chat runs a deterministic local workflow for the six supplied cases. To enable model-driven tool calling, set `OPENAI_API_KEY` in the server environment. `OPENAI_MODEL` defaults to `gpt-5.4-mini`. The key is never sent to the browser or written to logs.

`MAX_TOOL_ITERATIONS`, `MAX_SESSION_TOKENS` and `MAX_TOTAL_TOKENS` bound model work per turn, per session and per server process. Defaults are 10, 30,000 and 120,000 estimated tokens respectively.

The frontend, Node HTTP API and simulated SAP adapter use the same server process. For a production deployment, configure a persistent disk for `out/`, set the API key in the host's secret store and deploy this directory as a Node service.

## Model-free demo

```bash
pnpm demo
```

The demo clears `out/`, processes `req-001` through `req-006` by calling the tools directly, retries `req-001` to demonstrate idempotency, and explicitly confirms the quote variance on `req-004`. It requires no model key. Runtime artifacts are written to `out/` and are excluded from Git.

## API

- `GET /api/health` returns provider and model names without secrets.
- `POST /api/chat` accepts `{ "sessionId"?: string, "message": string }` and returns `{ sessionId, reply, toolCalls, needsConfirmation }`.
- `GET /api/sessions/:id` returns the visible conversation and confirmation state.

The session store is in memory. The file-backed order ledger and audit artifacts live under `out/`.

## Test link

Local test URL: [http://localhost:3000](http://localhost:3000). A hosted public test URL has not been provisioned in this handoff; deployment instructions are in `SOLUTION.md`.

## Files

- `agent/prompt.md` contains behavior rules.
- `src/knowledge/purchase-orders.md` contains process knowledge.
- `src/tools/po.ts` contains the Zod-typed tools and control logic.
- `src/sap/adapter.ts` and `src/sap/mock.ts` contain the SAP adapter contract and file-backed mock.
- `module/` packages the prompt, process skill and reusable tool entry point.

## Generated outputs

- `out/<case>/approval.txt` and `traceability.json`
- `out/sap/orders.jsonl`
- `out/control.csv`
- `out/log.jsonl`

Fixture data is fictional. The application does not connect to real SAP, send email or create real purchase orders.
